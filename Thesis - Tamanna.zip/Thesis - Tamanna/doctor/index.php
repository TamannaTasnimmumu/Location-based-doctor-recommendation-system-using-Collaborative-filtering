<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title>DRS</title>

    <link rel="icon" href="assets/icon/Industry-Icon-10%20(48).ico">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <style>
        @media only screen and (max-width: 600px) {
            .head-link-responsive {
                margin-top: 8% !important;
                font-size: 28px;
            }

            .widget-summary .summary .amount {
                font-size: 1.8rem;
            }

        }

    </style>

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>
</head>

<body>
    <center>
        <br><br>
        <a href="index.php" style="text-decoration:none;">
            <h1 class="head-link-responsive">LOCATION BASED DOCTOR RECOMMENDATION<br>SYSTEM</h1>
        </a>
        <br>
    </center>
    <div class="container" style="margin-top:50px;">
        <div class="col-md-12 col-lg-12 col-xl-12">
            <div class="row">
                <div class="col-md-12 col-lg-6 col-xl-6">
                    <a href="user.php" class="decoration-anchor">
                        <section class="panel panel-featured-left panel-featured-primary">
                            <div class="panel-body">
                                <div class="widget-summary">
                                    <div class="widget-summary-col widget-summary-col-icon">
                                        <div class="summary-icon bg-primary">
                                            <i class="fa fa-users"></i>
                                        </div>
                                    </div>
                                    <div class="widget-summary-col">
                                        <div class="summary">
                                            <h4 class="title">.</h4>
                                            <div class="info">
                                                <strong class="amount">Patients Login/Registration</strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </a>
                </div>
                <div class="col-md-12 col-lg-6 col-xl-6">
                    <a href="doctor/" class="decoration-anchor">
                        <section class="panel panel-featured-left panel-featured-secondary">
                            <div class="panel-body">
                                <div class="widget-summary">
                                    <div class="widget-summary-col widget-summary-col-icon">
                                        <div class="summary-icon bg-secondary">
                                            <i class="fa fa-user"></i>
                                        </div>
                                    </div>
                                    <div class="widget-summary-col">
                                        <div class="summary">
                                            <h4 class="title">.</h4>
                                            <div class="info">
                                                <strong class="amount">Doctors Login/Registration</strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="container" style="margin-top:150px;">
        <center>
            <p>
                Copyright©2019 Developed by <a href="#">Tamanna Tasnim</a>
            </p>
        </center>
    </div>

</body>

</html>
