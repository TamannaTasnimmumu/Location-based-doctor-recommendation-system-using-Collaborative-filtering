<?php
    include 'login_success.php';
    include 'includes/dbconnection.php';
    $email = $_SESSION["email"];
    $bmdc = $_GET['bmdc_no'];

if(isset($_REQUEST['rate_doctor'])){
   
    $rating = trim($_REQUEST['rating']);

    if(empty($rating)){
      $error = "Please select stars";
    }
      

    if(!isset($error)){
        $sql = 'SELECT * from rating where bmdc=:bmdc_no and email=:email_add';
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':bmdc_no', $_GET['bmdc_no']);
        $stmt->bindParam(':email_add', $email);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if($stmt->rowCount() > 0){
           echo "<script>alert('Previously rated by you');</script>";
          
        }else{
          $sql = "INSERT INTO rating(bmdc, email, rating) VALUES (:bmdc, :email, :rating)";
          $insert_stmt = $db->prepare($sql);
          $insert_stmt->bindParam(':bmdc', $_GET['bmdc_no']);
          $insert_stmt->bindParam(':email', $email);
          $insert_stmt->bindParam(':rating', $rating);

      if($insert_stmt->execute()){
        $insert_stmt = $db->prepare("SET @count = 0");
        $insert_stmt->execute();

          echo "<script>alert('Rating Added Successfully');</script>";
        }else{
          echo "<script>alert('Rating Not Added');</script>";
        }
        }
        
      
    }else{
      echo "<script>alert('Something Wrong!!!Try Again');</script>";
    }
  }




 ?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title>DRS | Doctor</title>

    <link rel="icon" href="assets/icon/Industry-Icon-10%20(48).ico">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/rating.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>
<!--
     <script>
        $(document).ready(function() {
            $(".backup_picture").on("error", function() {
                $(this).attr('src', './doctor/doctor.png');
            });
        });

    </script>
-->

</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php include 'includes\header.php'; ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include 'includes\sidebar.php'; ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header">

                </header>
                <div class="container">
                    <?php
                      $select_stmt = $db->prepare("SELECT * FROM doctor WHERE bmdc=:bmdc");
                      $select_stmt ->bindParam(':bmdc',$_GET['bmdc_no']);
                      $select_stmt->execute();
                      $row1 = $select_stmt->fetch(PDO::FETCH_ASSOC);
                    ?>
                    <div class="col-md-4">
                        <!--                        <img src="doctor/doctor.png" alt="">-->
                        <img class="backup_picture" src="doctor/assets/img/<?php echo $bmdc;?>.png" onerror="this.onerror=null;this.src='doctor/doctor.png';" height="218" width="182"> 
                        <h4>Add a review</h4>
                        <form action="" method="post">
                            <fieldset class="rating">
                                <input type="radio" id="star5" name="rating" value="5" /><label class="full" for="star5" title="Awesome - 5 stars"></label>
                                <input type="radio" id="star4half" name="rating" value="4.5" /><label class="half" for="star4half" title="Pretty good - 4.5 stars"></label>
                                <input type="radio" id="star4" name="rating" value="4" /><label class="full" for="star4" title="Pretty good - 4 stars"></label>
                                <input type="radio" id="star3half" name="rating" value="3.5" /><label class="half" for="star3half" title="Meh - 3.5 stars"></label>
                                <input type="radio" id="star3" name="rating" value="3" /><label class="full" for="star3" title="Meh - 3 stars"></label>
                                <input type="radio" id="star2half" name="rating" value="2.5" /><label class="half" for="star2half" title="Kinda bad - 2.5 stars"></label>
                                <input type="radio" id="star2" name="rating" value="2" /><label class="full" for="star2" title="Kinda bad - 2 stars"></label>
                                <input type="radio" id="star1half" name="rating" value="1.5" /><label class="half" for="star1half" title="Meh - 1.5 stars"></label>
                                <input type="radio" id="star1" name="rating" value="1" /><label class="full" for="star1" title="Sucks big time - 1 star"></label>
                                <input type="radio" id="starhalf" name="rating" value=".5" /><label class="half" for="starhalf" title="Sucks big time - 0.5 stars"></label>
                            </fieldset>
                            <br>
                            <br>
                            <input class="btn btn-info text-left" type="submit" name="rate_doctor" value="Submit" />

                        </form>

                    </div>
                    <div class="table-repsonsive col-md-8" style="100%;">
                        <table>

                            <!--                             doctor name-->
                            <tbody class="text-center">
                                <tr>
                                    <th width="50%">
                                        <h4>Doctor Name: </h4>
                                    </th>
                                    <th width="5%"> :</th>
                                    <th>
                                        <h4>
                                            <?php echo $row1['doctor_name']; ?>
                                        </h4>
                                    </th>
                                </tr>
                                <?php
                                    $stmt_rat = $db->prepare('SELECT AVG(rating) as avg_rat from rating WHERE bmdc = :bmdc');
                                    $stmt_rat->bindParam(':bmdc', $bmdc);
                                    $stmt_rat->execute();
                                    $r = $stmt_rat->fetch(PDO::FETCH_ASSOC);
                                        
                                    
                                    $stmt_rat = $db->prepare('SELECT * from rating WHERE bmdc = :bmdc');
                                    $stmt_rat->bindParam(':bmdc', $bmdc);
                                    $stmt_rat->execute();
                                    $stmt_rat->fetch(PDO::FETCH_ASSOC);
                                    $total_row = $stmt_rat->rowCount();
                                ?>
                                <tr>
                                    <th width="50%">
                                        <h4>Rating Point: </h4>
                                    </th>
                                    <th width="5%"> :</th>
                                    <th>
                                        <h4>
                                                
                                                 <?php if($r['avg_rat'] == 0){
                                                    echo "5 (Not Rated yet)";
                                                }else{
                                                    echo round($r['avg_rat'],2)." (".$total_row." person rated)";
                                                }

                                                ?>
                                            </h4>
                                    </th>
                                </tr>
                                <?php
                                        $count = 0;
                                           $select_stmt = $db->prepare("SELECT * FROM doctor_degree WHERE bmdc='$bmdc' ORDER BY id");
                                           $select_stmt->execute();
                                           
                                            while($row = $select_stmt->fetch(PDO::FETCH_ASSOC)){
                                                $count++;
                                            ?>
                                    <tr>
                                        <th width="50%">
                                            <h4>Degree <?php echo $count;?></h4>
                                        </th>
                                        <th width="5%"> :</th>
                                       
                                        <th>
                                          
                                           <h4>
                                                <?php echo $row['degree']; ?>
                                            </h4>
                                           
                                        </th>
                                        
                                    </tr>
                                    <?php }
                                            ?>
                                 <?php
                                           $count = 0;
                                           $select_stmt = $db->prepare("SELECT * FROM doctor_specialty WHERE bmdc='$bmdc'");
                                           $select_stmt->execute();
                                           
                                            while($row = $select_stmt->fetch(PDO::FETCH_ASSOC)){
                                                $count++;
                                            ?>
                                    <tr>
                                        <th width="50%">
                                            <h4>Doctor Specialty <?php echo $count;?></h4>
                                        </th>
                                        <th width="5%"> :</th>
                                       
                                        <th>
                                          
                                           <h4>
                                                <?php echo $row['specialty']; ?>
                                            </h4>
                                           
                                        </th>
                                        
                                    </tr>
                                    <?php }
                                            ?>
                                <tr>
                                    <th width="50%">
                                        <h4>BMDC Number </h4>
                                    </th>
                                    <th width="5%"> :</th>
                                    <th>
                                        <h4>
                                            <?php echo $bmdc; ?>
                                        </h4>
                                    </th>
                                </tr>
                                <?php
                                   $count = 0;
                                   $select_stmt = $db->prepare("SELECT * FROM doctor_chamber_list WHERE bmdc='$bmdc'");
                                   $select_stmt->execute();

                                    while($row = $select_stmt->fetch(PDO::FETCH_ASSOC)){
                                        $count++;
                                    ?>
                                <tbody style="border: 5px solid #fff; background-color:#f9f9f9; margin:10px;" class="text-center">
                                    
                                    <tr>
                                        <th width="50%" style="padding-left:5%; padding-top:5%;">
                                            <h4>Chamber Address <span style="color:red;"><?php echo $count;?></span></h4>
                                        </th>
                                        <th width="5%"> :</th>
                                       
                                        <th style="padding-top:5%;">
                                          
                                           <h4>
                                                <?php echo $row['area']; ?>
                                            </h4>
                                           
                                        </th>
                                        
                                    </tr>
                                     <tr>
                                        <th width="50%" style="padding-left:5%;">
                                            <h4>Appointment Schedule </h4>
                                        </th>
                                        <th width="5%"> :</th>
                                        <th>
                                            <h4>
                                                <?php echo $row['appointment_schedule']; ?>
                                            </h4>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th width="50%" style="padding-left:5%; padding-bottom:5%;">
                                            <h4>Doctor Fees </h4>
                                        </th>
                                        <th width="5%"> :</th>
                                        <th style="padding-bottom:5%;">
                                            <h4>
                                                <?php echo $row['fees']; ?><span> BDT</span>
                                            </h4>
                                        </th>
                                    </tr>
                                    <?php }
                                            ?>
                                </tbody>
                                <tr>
                                    <th width="50%">
                                        <h4>Contact Number </h4>
                                    </th>
                                    <th width="5%"> :</th>
                                    <th>
                                        <h4>
                                            <?php echo $row1['contact']; ?>
                                        </h4>
                                    </th>
                                </tr>
                               
<!--                            </tbody>-->

                            

                        </table>
                    </div>
                    <?php     
                     ?>

                </div>
            </section>
        </div>


    </section>

    <div class="footerarea">
        <center>
            <p>Copyright©
                <?php echo date("Y"); ?> Developed by <a href="#">Tamanna Tasnim</a></p>
        </center>

    </div>

    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>
   
</body>

</html>
