<header class="header">
  <div class="logo-container">
    <a href="../" class="logo">
      <img src="assets/icon/Industry-Icon-10%20(48).ico" height="35" alt="logo" />
    </a>
    <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
      <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
    </div>
  </div>

    <div id="userbox" class="userbox" style="float:right;">

          </div>

</header>
