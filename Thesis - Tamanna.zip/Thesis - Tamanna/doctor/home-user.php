<?php
    include 'login_success.php';
    include 'includes/dbconnection.php';
    $email = $_SESSION["email"];

 ?>
<!doctype html>
<html class="fixed">

<head>
    <!-- Basic -->
    <meta charset="UTF-8">
    <title>DRS | Patient</title>
    <link rel="icon" href="assets/icon/Industry-Icon-10%20(48).ico">
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />
    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />
    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />
    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />
    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        @media (min-width: 768px){
            .col-md-3 {
            width: 50%;
            }
        }
    </style>
    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>
</head>

<body>
    <section class="body">
        <!-- start: header -->
        <?php include 'includes\header.php'; ?>
        <!-- end: header -->
        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include 'includes\sidebar.php'; ?>
            <!-- end: sidebar -->
            <section role="main" class="content-body">
                <header class="page-header">
                    <table>
                        <tbody class="text-center">
                            <?php
                                      $select_stmt = $db->prepare("SELECT patient_name FROM patient WHERE email='$email'");
                                      $select_stmt->execute();

                                      while($row = $select_stmt->fetch(PDO::FETCH_ASSOC))
                                        {?>
                            <tr>
                                <th>
                                    <h2>
                                        <?php echo $row['patient_name']; ?>
                                    </h2>
                                </th>
                            </tr>
                            <?php } 
                                    
                                    ?>
                        </tbody>
                    </table>
                </header>
                <div class="container">
                    <form method="post" action="">
                        <div class="table-repsonsive" style="100%;">
                            <table>
                                <tr>
                                    <th width="32%">
                                        <select name="p_location" id="p_location" class="form-control invoice-box-size-width">
                                            <option>Select Preferred Location</option>
                                            <?php
                                            $sql = "SELECT * FROM location";
                                            $res = $db->prepare($sql);
                                            $res->execute();
                                            $results = $res->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($results as $row) {
                                              echo '<option value="'.$row['area'].'">'.$row['area'].'</option>';
                                            }

                                            ?>
                                        </select>
                                    </th>
                                    <th width="2%"></th>
                                    <th width="32%">
                                        <select name="p_speciality" id="p_speciality" class="form-control invoice-box-size-width">
                                            <option>Select Speciality</option>
                                            <?php
                                            $sql = "SELECT * FROM specialist";
                                            $res = $db->prepare($sql);
                                            $res->execute();
                                            $results = $res->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($results as $row) {
                                              echo '<option value="'.$row['specialist'].'">'.$row['specialist'].'</option>';
                                            }

                                            ?>
                                        </select>
                                    </th>
                                    <th width="2%"></th>
                                    <th width="32%">
                                        <select name="topk" id="topk">
                                            <option value="5">5</option>
                                            <option value="10">10</option>
                                            <option value="all">All</option>
                                        </select>
                                    </th>
                                </tr>
                                 <tr>
                                    <th width="32%">
                                        
                                    </th>
                                    <th width="2%"></th>
                                    <th width="32%">
                                       <br>
                                    </th>
                                    <th width="2%"></th>
                                    <th width="32%">
                                        
                                    </th>
                                </tr>
                                <tr>
                                    <th width="32%">
                                        
                                    </th>
                                    <th width="2%"></th>
                                    <th width="32%">
                                       <input type="submit" name="search" id="search" class="btn btn-info" value="search" />
                                    </th>
                                    <th width="2%"></th>
                                    <th width="32%">
                                        
                                    </th>
                                </tr>
                            </table>
                        </div>
                    </form>
                </div>
            </section>
            <section role="main" class="content-body">
                <div class="container">
                    <div style="margin-left:25%;">
                        <h3 class="font-weight-bold">All Recommended Doctors</h3>
                    </div>
                    <div class="col-md-12">
                        <?php
                        if(isset($_POST['search'])){
                        $location = $_POST['p_location'];
                        $spaciality = $_POST['p_speciality'];
                        $topk = $_POST['topk'];
                        
                        $stmt = $db->prepare('SELECT * from location where area = :area');
                        $stmt->bindParam(':area', $location);
                        $stmt->execute();
                        $stmt->bindColumn('latitude', $lat);
                        $stmt->bindColumn('longitude', $lon);
                        $stmt->fetch();
                        
//                        $new_lat = (float)$lat + 0.010000;
//                        $new_lon = (float)$lon + 0.010000;
//                            
//                        $new_lat_one = (float)$lat - 0.010000;
//                        $new_lon_one = (float)$lon - 0.010000;


//                        $stmt = $db->prepare("SELECT d.* FROM doctor as d JOIN doctor_specialty as ds JOIN doctor_chamber_list as dcl on d.bmdc = ds.bmdc and d.bmdc = dcl.bmdc where specialty= :spe AND latitude BETWEEN {$new_lat_one} and {$new_lat} AND longitude BETWEEN {$new_lon_one} and {$new_lon} GROUP BY d.bmdc");  
                            
                        $stmt = $db->prepare("SELECT d.* FROM doctor as d JOIN doctor_specialty as ds on d.bmdc = ds.bmdc where specialty= :spe GROUP BY d.bmdc");    
                        

                        $stmt->bindParam(':spe', $spaciality);
                        $stmt->execute();
                        
                        $all_bmdc = array();
                        $avg_rating = array();
                        $new_array = array();
                            
                      while($row = $stmt->fetch(PDO::FETCH_ASSOC))
                        {
                            $stmt_rat = $db->prepare('SELECT * FROM doctor_chamber_list WHERE bmdc = :bmdc');
                            $stmt_rat->bindParam(':bmdc', $row['bmdc']);
                            $stmt_rat->execute();
                            $r = $stmt_rat->fetch(PDO::FETCH_ASSOC);
                            
                            $newlat = $r['latitude'];
                            $newlon = $r['longitude'];
                            
                            $doclen = sqrt(pow(($lat - $newlat),2) + pow(($lon - $newlon),2));
                          
                            if($doclen<=0.010000){
                                $all_bmdc[] = $r['bmdc'];
                            }                            
                            
                            
                         }
                            foreach($all_bmdc as $bmdc){
                                    $stmt_rat = $db->prepare('SELECT * from rating WHERE bmdc = :bmdc');
                                    $stmt_rat->bindParam(':bmdc', $bmdc);
                                    $stmt_rat->execute();
                                    $stmt_rat->fetch(PDO::FETCH_ASSOC);
                                    $total_row = $stmt_rat->rowCount();
                                    
                                    
                                    $no_of_person[] = $total_row;
                                    //$p_rated[] = $total_row;
                                
                                
                                    $stmt_rat = $db->prepare('SELECT AVG(rating) as avg_rat from rating WHERE bmdc = :bmdc');
                                    $stmt_rat->bindParam(':bmdc', $bmdc);
                                    $stmt_rat->execute();
                                    $r = $stmt_rat->fetch(PDO::FETCH_ASSOC);
                                    $avg_rating[] = round($r['avg_rat'],2);  
                                
                                //Doctors degree count 
                                
                                    $stmt_rat = $db->prepare('SELECT * FROM doctor_degree WHERE bmdc = :bmdc');
                                    $stmt_rat->bindParam(':bmdc', $bmdc);
                                    $stmt_rat->execute();
                                    $stmt_rat->fetch(PDO::FETCH_ASSOC);
                                    $total_degree[] = $stmt_rat->rowCount();
                                    
                            }
                            

                            
                            for ($i=0; $i<count($no_of_person); $i++){
                                if($no_of_person[$i]== 0){
                                    $weighted_value[$i] = 0.5;
                                }else if($no_of_person[$i] >=1 && $no_of_person[$i] <=50){
                                    $weighted_value[$i] = 1;
                                }else if($no_of_person[$i] >=51 && $no_of_person[$i] <=100){
                                    $weighted_value[$i] = 2;
                                }else if($no_of_person[$i] >=101 && $no_of_person[$i] <=150){
                                    $weighted_value[$i] = 3;
                                }else if($no_of_person[$i] >=151 && $no_of_person[$i] <=200){
                                    $weighted_value[$i] = 4;
                                }else if($no_of_person[$i] >=201 && $no_of_person[$i] <=250){
                                    $weighted_value[$i] = 5;
                                }else if($no_of_person[$i] >=251 && $no_of_person[$i] <=300){
                                    $weighted_value[$i] = 6;
                                }else if($no_of_person[$i] >=301 && $no_of_person[$i] <=350){
                                    $weighted_value[$i] = 7;
                                }else if($no_of_person[$i] >=351 && $no_of_person[$i] <=400){
                                    $weighted_value[$i] = 8;
                                }else if($no_of_person[$i] >=401 && $no_of_person[$i] <=450){
                                    $weighted_value[$i] = 9;
                                }else if($no_of_person[$i] >=451 && $no_of_person[$i] <=500){
                                    $weighted_value[$i] = 10;
                                }else if($no_of_person[$i] >=501 && $no_of_person[$i] <=550){
                                    $weighted_value[$i] = 11;
                                }else if($no_of_person[$i] >=551 && $no_of_person[$i] <=600){
                                    $weighted_value[$i] = 12;
                                }else if($no_of_person[$i] >=601 && $no_of_person[$i] <=650){
                                    $weighted_value[$i] = 13;
                                }else if($no_of_person[$i] >=651 && $no_of_person[$i] <=700){
                                    $weighted_value[$i] = 14;
                                }else if($no_of_person[$i] >=701 && $no_of_person[$i] <=750){
                                    $weighted_value[$i] = 15;
                                }else if($no_of_person[$i] >=751 && $no_of_person[$i] <=800){
                                    $weighted_value[$i] = 16;
                                }else if($no_of_person[$i] >=801 && $no_of_person[$i] <=850){
                                    $weighted_value[$i] = 17;
                                }else if($no_of_person[$i] >=851 && $no_of_person[$i] <=900){
                                    $weighted_value[$i] = 18;
                                }else if($no_of_person[$i] >=901 && $no_of_person[$i] <=950){
                                    $weighted_value[$i] = 19;
                                }else if($no_of_person[$i] >=951 && $no_of_person[$i] <=1000){
                                    $weighted_value[$i] = 20;
                                }else{
                                    $weighted_value[$i] = 21;
                                }
                            }
                             
                            
//                            rsort($no_of_person);
//                            $highest_rated_no = $no_of_person[0];

                            
                            for($i = 0; $i < count($weighted_value); $i++){

                                    
//                                    $final_avg_rating[$i] = ($weighted_value[$i] * $avg_rating[$i]);
                                $final_avg_rating[$i] = (($weighted_value[$i] * $avg_rating[$i])+$total_degree[$i])/2;

                            }
                            
                            
                            $new_array  = array_combine($all_bmdc, $final_avg_rating);

                            arsort($new_array);
                            if($topk == 5){
                                $result = array_slice($new_array,0,5,true);
                            }else if($topk == 10){
                                $result = array_slice($new_array,0,10,true);
                            }else{
                                $result = $new_array;
                            }
                            

                            
                            foreach($result as $key=>$value){
                             
                                $stmt = $db->prepare("SELECT * FROM doctor where bmdc = :bmdc_no");
                                $stmt->bindParam(':bmdc_no', $key);
                                $stmt->execute();
                                
                                 while($row1 = $stmt->fetch(PDO::FETCH_ASSOC))
                                 {?>
                                    
                                    <div class="col-md-9" style="background-color:#bdc3c7; margin:10px; padding:20px; border: 5px solid #fff;">
                            <table>
                                <tr>
                                    <th colspan="3">
                                        <?php echo $row1['doctor_name'], $row1['bmdc']; ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th colspan="3">
                                        <?php echo $spaciality; ?>
                                    </th>
                                </tr>
                                
                                <?php
                                        $bmdc = $row1['bmdc'];
                                        $count = 0;
                                           $select_stmt = $db->prepare("SELECT * FROM doctor_degree WHERE bmdc='$bmdc' ORDER BY id");
                                           $select_stmt->execute();
                                           
                                            while($row2 = $select_stmt->fetch(PDO::FETCH_ASSOC)){
                                                $count++;
                                            ?>
                                    <tr>
                                        <th>
                                            Degree <?php echo $count;?>
                                        </th>
                                        <th width="5%"> :</th>
                                       
                                        <th><?php echo $row2['degree']; ?></th>
                                    </tr>
                                    <?php }
                                            ?>
                                <?php
                                   $count = 0;
                                   $select_stmt = $db->prepare("SELECT * FROM doctor_chamber_list WHERE bmdc='$bmdc'");
                                   $select_stmt->execute();

                                    while($row = $select_stmt->fetch(PDO::FETCH_ASSOC)){
                                        $count++;
                                    ?>
                                    
                                    <tr>
                                        <th>
                                            Chamber Address <span style="color:red;"><?php echo $count;?></span>
                                        </th>
                                        <th width="5%"> :</th>
                                       
                                        <th>
                                                <?php echo $row['area']; ?>
                                        </th>
                                        
                                    </tr>
                                     <tr>
                                        <th>Appointment Schedule</th>
                                        <th width="5%"> :</th>
                                        <th>
                                                <?php echo $row['appointment_schedule']; ?>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th style="padding-bottom:5%;">Doctor Fees</th>
                                        <th style="padding-bottom:5%;" width="5%"> :</th>
                                        <th style="padding-bottom:5%;">
                                                <?php echo $row['fees']; ?><span> BDT</span>
                                        </th>
                                    </tr>
                                <?php }
                                            ?>
                                <?php
                                    $stmt_rat = $db->prepare('SELECT AVG(rating) as avg_rat from rating WHERE bmdc = :bmdc');
                                    $stmt_rat->bindParam(':bmdc', $row1['bmdc']);
                                    $stmt_rat->execute();
                                    $r = $stmt_rat->fetch(PDO::FETCH_ASSOC);
                                  
                            
                         
                                    
                                    $stmt_rat = $db->prepare('SELECT * from rating WHERE bmdc = :bmdc');
                                    $stmt_rat->bindParam(':bmdc', $row1['bmdc']);
                                    $stmt_rat->execute();
                                    $stmt_rat->fetch(PDO::FETCH_ASSOC);
                                    $total_row = $stmt_rat->rowCount();
                                  
                                    
                                ?>
                                <tr>
                                   <th>Rating</th>
                                    <th width="5%"> :</th>
                                    <th>
                                        <?php if($r['avg_rat'] == 0){
                                                echo "5 (Not Rated yet)";
                                            }else{
                                                echo round($r['avg_rat'],2)." (".$total_row." person rated)";
                                            }
                         
                          ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th width="65%" style="float:left; margin-top:5%;"><a href="view_profile.php?bmdc_no=<?php echo $row1['bmdc'];?>"><input id="view-profile" type="submit" name="view-profile" class="btn btn-info" value="view profile" /></a></th>
                                </tr>
                            </table>
                        </div>
                                 <?php 
                                 }
                            }
                        }
                        ?>
                    </div>
                </div>
            </section>
        </div>
    </section>
    <div class="footerarea">
        <center>
            <p>Copyright©
                <?php echo date("Y"); ?> Developed by <a href="#">Tamanna Tasnim</a></p>
        </center>
    </div>
    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>
    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>
    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>
    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>
    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>
</body>

</html>
