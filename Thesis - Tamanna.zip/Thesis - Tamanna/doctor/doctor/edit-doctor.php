<?php
  //include 'login_success.php';
session_start();
  include 'includes/dbconnection.php';

    
  if(isset($_REQUEST['bmdc'])){
    try{
        $bmdc = $_REQUEST['bmdc'];
        $select_stmt = $db->prepare('SELECT * FROM doctor WHERE bmdc =:bmdc');
        $select_stmt->bindParam(':bmdc',$bmdc);
        $select_stmt->execute();
        $row = $select_stmt->fetch(PDO::FETCH_ASSOC);
        extract($row);
    }catch(PDOException $e){
      $e->getMessage();
    }
    
  }

    if(isset($_REQUEST['update'])){
    $doctor_address = trim($_REQUEST['doctor_address']);
    $doctor_area = trim($_REQUEST['doctor_area']);
    $doctor_specialist = trim($_REQUEST['doctor_specialist']);
    $educational_qualification = trim($_REQUEST['educational_qualification']);
    $appointment_schedule = trim($_REQUEST['appointment_schedule']);
    $contact = trim($_REQUEST['contact']);
    $doctor_fees = trim($_REQUEST['doctor_fees']);
    
   if(empty($doctor_address)){
      $error = "Please enter your address";
    }if(empty($doctor_area)){
      $error = "Please select your location";
    }if(empty($doctor_specialist)){
      $error = "Please select your speciality";
    }if(empty($educational_qualification)){
      $error = "Please enter your educational qualification";
    }if(empty($appointment_schedule)){
      $error = "Please enter your appointment schedule";
    }if(empty($contact)){
      $error = "Please enter contact number";
    }if(empty($doctor_fees)){
      $error = "Please enter doctor fees";
    }


    $stmt = $db->prepare('SELECT * from location where area = :area');
    $stmt->bindParam(':area', $doctor_area);
    $stmt->execute();
    $stmt->bindColumn('latitude', $lat);
    $stmt->bindColumn('longitude', $lon);
    $stmt->fetch();


    if(!isset($error)){
      $sql = "UPDATE doctor SET doctor_address=:doctor_address, doctor_area=:doctor_area, 
            doctor_latitude=:doctor_latitude, doctor_longitude=:doctor_longitude,  doctor_specialist=:doctor_specialist, educational_qualification=:educational_qualification, appointment_schedule=:appointment_schedule, contact=:contact, doctor_fees=:doctor_fees
            WHERE bmdc = :bmdc";
      $insert_stmt = $db->prepare($sql);
      
      $insert_stmt->bindParam(':doctor_address', $doctor_address);
      $insert_stmt->bindParam(':doctor_area', $doctor_area);
      $insert_stmt->bindParam(':doctor_latitude', $lat);
      $insert_stmt->bindParam(':doctor_longitude', $lon);
      $insert_stmt->bindParam(':doctor_specialist', $doctor_specialist);
      $insert_stmt->bindParam(':educational_qualification', $educational_qualification);
      $insert_stmt->bindParam(':appointment_schedule', $appointment_schedule);
      $insert_stmt->bindParam(':contact', $contact);
      $insert_stmt->bindParam(':doctor_fees', $doctor_fees);
      $insert_stmt->bindParam(':bmdc', $bmdc);

      if($insert_stmt->execute()){
        $insert_stmt = $db->prepare("SET @count = 0");
        $insert_stmt->execute();

        $insert_stmt = $db->prepare("UPDATE doctor SET doctor_id = @count:= @count + 1");
        $insert_stmt->execute();

        $insert_stmt = $db->prepare("ALTER TABLE doctor AUTO_INCREMENT = 1");
        $insert_stmt->execute();
          echo "<script>alert('Update Successful');</script>";
          $query = "SELECT * FROM doctor WHERE email = :email AND password = :password";
                $statement = $db->prepare($query);
                $statement->execute(
                     array(
                          ':email'     =>     $row['email'],
                          ':password'     =>  $row['password']
                     )
                );
                $count = $statement->rowCount();
                if($count > 0)
                {
                     $_SESSION["email"] = $email;
                     header("location:home-doctor.php");
                }
        }else{
          echo "<script>alert('doctor Not Added');</script>";
        }
    }else{
        echo "<script>alert('Something Wrong');</script>";
    }
   
    
    
      
    
  }
?>
    <!doctype html>
    <html class="fixed">

    <head>
        <!-- Basic -->
        <meta charset="UTF-8">
        <title>Edit Doctor</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="icon" href="assets/icon/Industry-Icon-10%20(48).ico">
        <!-- contact Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>
    

        

</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php include 'includes\header.php'; ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <aside id="sidebar-left" class="sidebar-left">

                <div class="sidebar-header">
                    <div class="sidebar-title">
                        Navigation
                    </div>
                    <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
                        <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                    </div>
                </div>

                <div class="nano">
                    <div class="nano-content">
                        <nav id="menu" class="nav-main" role="navigation">
                            <ul class="nav nav-main">

                                <li>
                                    <a href="home-doctor.php">
                                        <i class="fa fa-copy" aria-hidden="true"></i>
                                        <span>Profile</span>
                                    </a>
                                </li>

                                <li>
                                    <a href="edit-doctor.php?bmdc=<?php echo $bmdc; ?>">
                                        <i class="fa fa-copy" aria-hidden="true"></i>
                                        <span>Edit Profile</span>
                                    </a>
                                </li>

                                <li>
                                    <a href="logout.php">
                                        <i class="fa fa-bar-chart-o" aria-hidden="true"></i>
                                        <span>Logout</span>
                                    </a>
                                </li>

                            </ul>
                        </nav>

                    </div>

                </div>

            </aside>

            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header">
                    <table>
                        <tbody class="text-center">
                            <tr>
                                <th>
                                    <h2>
                                        <?php echo $row['doctor_name']; ?>
                                    </h2>
                                </th>
                            </tr>
                        </tbody>
                    </table>
                </header>
                <div class="container">
            <form class="form-signin" action="" method="post" accept-charset="utf-8">
                <h1 class="h3 mb-3 font-weight-normal" style="margin-top:20px;">Edit Doctor's Profile</h1>
                <input class="form-control" type="text" placeholder="Doctor Name" disabled autocomplete="off" name="doctor_name" value="<?php echo $row['doctor_name']?>"/>
                <input class="form-control" type="text" placeholder="Doctor's Chamber Address" autocomplete="off" name="doctor_address" value="<?php echo $row['doctor_address']?>"/>
                <!--
            <input class="form-control" type="text" placeholder="Doctor Address" autocomplete="off" name="doctor_address" />
            <input class="form-control" type="text" placeholder="Doctor Specialist" autocomplete="off" name="doctor_specialist" />
-->
                <table style="width: 100%;">
                    <tr>
                        <th width="100%">
                            <select name="doctor_area" id="doctor_area" class="form-control invoice-box-size-width">
                                <option>Select Location</option>
                                <?php
                            $sql = "SELECT * FROM location";
                            $res = $db->prepare($sql);
                            $res->execute();
                            $results = $res->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($results as $row_r) {
                              if($row_r['area'] == $row['doctor_area']){
                                    echo '<option selected value="'.$row_r['area'].'">'.$row_r['area'].'</option>';
                                }else{
                                  echo '<option value="'.$row_r['area'].'">'.$row_r['area'].'</option>';
                              }
                              
                                
                                
                            }                     
                            ?>
                            </select>
                        </th>
                    </tr>
              
                </table>
                <table style="width: 100%;">
                    <tr>
                        <th width="100%">
                            <select name="doctor_specialist" id="doctor_specialist" class="form-control invoice-box-size-width">
                                <option>Select Speciality</option>
                                <?php
                                $sql = "SELECT * FROM specialist";
                                $res = $db->prepare($sql);
                                $res->execute();
                                $results = $res->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($results as $row_r) {
                                    if($row_r['specialist'] == $row['doctor_specialist']){
                                        echo '<option selected value="'.$row_r['specialist'].'">'.$row_r['specialist'].'</option>';
                                    }else{
                                        echo '<option value="'.$row_r['specialist'].'">'.$row_r['specialist'].'</option>';
                                    }
                                  
                                }

                                ?>
                            </select>
                        </th>
                    </tr>
                </table>
                <input class="form-control" type="text" placeholder="Educational Qualification" autocomplete="off" name="educational_qualification" value="<?php echo $row['educational_qualification']?>"/>
                <input class="form-control" type="text" placeholder="Appointment Schedule" autocomplete="off" name="appointment_schedule" value="<?php echo $row['appointment_schedule']?>" />
            
                <input class="form-control" type="text" placeholder="BMDC Number" autocomplete="off" disabled name="bmdc" value="<?php echo $row['bmdc']?>"/>
                
            
                <input class="form-control" type="text" placeholder="Contact Number" autocomplete="off" name="contact" value="<?php echo $row['contact']?>" />
                <input class="form-control" type="text" placeholder="Doctor Fees" autocomplete="off" name="doctor_fees" value="<?php echo $row['doctor_fees']?>" />
                <input class="form-control" type="text" placeholder="Email" disabled autocomplete="off" name="email" value="<?php echo $row['email']?>" />
<!--                <input class="form-control" type="password" placeholder="Password" autocomplete="off" name="password" />-->
                <input class="btn btn-lg btn-primary btn-block" type="submit" name="update" value="Update" />
                <br>
                <br>
                <br>
                <p>Copyright©2019 Developed by <a href="#">Tamanna Tasnim</a></p>
            </form>
        </div>
            </section>
        </div>
    </section>
        <!-- Vendor -->
        <script src="assets/vendor/jquery/jquery.js"></script>
        <script src="assets/vendor/jquery-browser-contact/jquery.browser.contact.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
        <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
        <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
        <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
        <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
        <!-- Specific Page Vendor -->
        <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
        <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
        <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
        <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
        <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
        <script src="assets/vendor/flot/jquery.flot.js"></script>
        <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
        <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
        <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
        <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
        <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
        <script src="assets/vendor/raphael/raphael.js"></script>
        <script src="assets/vendor/morris/morris.js"></script>
        <script src="assets/vendor/gauge/gauge.js"></script>
        <script src="assets/vendor/snap-svg/snap.svg.js"></script>
        <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
        <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
        <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
        <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>
        <!-- Theme Base, Components and Settings -->
        <script src="assets/javascripts/theme.js"></script>
        <!-- Theme Custom -->
        <script src="assets/javascripts/theme.custom.js"></script>
        <!-- Theme Initialization Files -->
        <script src="assets/javascripts/theme.init.js"></script>
        <!-- Examples -->
        <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>
    </body>

    </html>