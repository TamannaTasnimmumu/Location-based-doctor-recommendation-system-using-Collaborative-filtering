<?php
 session_start();
 $host = "localhost";
 $username = "root";
 $password = "";
 $database = "takereg";
 $message = "";
 try
 {
      $connect = new PDO("mysql:host=$host; dbname=$database", $username, $password);
      $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      if(isset($_POST["login"]))
      {
           if(empty($_POST["email"]) || empty($_POST["password"]))
           {
                $message = '<label>All fields are required</label>';
           }
           else
           {
                $query = "SELECT * FROM doctor WHERE email = :email AND password = :password";
                $statement = $connect->prepare($query);
                $statement->execute(
                     array(
                          ':email'     =>     $_POST["email"],
                          ':password'     =>     $_POST["password"]
                     )
                );
                $count = $statement->rowCount();
                if($count > 0)
                {
                     $_SESSION["email"] = $_POST["email"];
                     header("location:home-doctor.php");
                }
                else
                {
                     $message = '<label>Wrong Data</label>';
                }
           }
      }
 }
 catch(PDOException $error)
 {
      $message = $error->getMessage();
 }
 ?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/icon/Industry-Icon-10%20(48).ico">

    <title>User Signin</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">
</head>

<body class="text-center">
    <div class="container">
       <?php
                if(isset($message))
                {
                     echo '<label class="text-danger">'.$message.'</label>';
                }
                ?>
        <center>
            <a href="../index.php" style="text-decoration:none; margin: 50px;"><h1 class="head-link-responsive">LOCATION BASED DOCTOR RECOMMENDATION<br>SYSTEM</h1></a>
            <br>
        </center>
        <form class="form-signin" method="post">

            <img class="mb-4" src="../assets/icon/Industry-Icon-10%20(48).ico" alt="" width="72" height="72">
            <h1 class="h3 mb-3 font-weight-normal">Doctors sign in</h1>
            <label for="inputEmail" class="sr-only">Email</label>
            <input type="text" id="inputEmail" name="email" class="form-control" placeholder="Email" required autofocus>
            <label for="inputPassword" class="sr-only">Password</label>
            <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
            <button class="btn btn-lg btn-primary btn-block" name="login" type="submit">Sign in</button>
            <br><p>Create new account <a href="add_doctor.php">Register Here</a></p>
            <br>
            
            <p style="margin-top:50px;">
                Copyright©2019 Developed by <a href="#">Tamanna Tasnim</a>
            </p>
        </form>
    </div>
</body>

</html>
