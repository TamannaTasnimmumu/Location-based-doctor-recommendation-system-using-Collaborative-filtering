<?php
  //include 'login_success.php';
session_start();
  include 'includes/dbconnection.php';

    
  if(isset($_REQUEST['add_doctor'])){
    $doctor_name = trim($_REQUEST['doctor_name']);
    $bmdc = trim($_REQUEST['bmdc']);
    $contact = trim($_REQUEST['contact']);
    $email = trim($_REQUEST['email']);
    $password = trim($_REQUEST['password']);

    if(empty($doctor_name)){
      $error = "Please enter your name";
    }if(empty($bmdc)){
      $error = "Please enter valid BMDC number";
    }if(empty($contact)){
      $error = "Please enter contact number";
    }if (!stristr($email,"@") OR !stristr($email,".")) {
      $error = "Please enter email";
    }if(empty($password)){
      $error = "Please enter password";
    }
    
    $stmt = $db->prepare('SELECT * from bmdc where doctor_name = :d_name and bmdc_no=:bmdc');
    $stmt->bindParam(':d_name', $doctor_name);
    $stmt->bindParam(':bmdc', $bmdc);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($stmt->rowCount() > 0){
        $stmt = $db->prepare('SELECT * from location where area = :area');
        $stmt->bindParam(':area', $doctor_area);
        $stmt->execute();
        $stmt->bindColumn('latitude', $lat);
        $stmt->bindColumn('longitude', $lon);
        $stmt->fetch();


    if(!isset($error)){
      $sql = "INSERT INTO doctor(doctor_name, bmdc, contact, email, password) VALUES (:doctor_name, :bmdc, :contact, :email, :password)";
      $insert_stmt = $db->prepare($sql);
      $insert_stmt->bindParam(':doctor_name', $doctor_name);
      $insert_stmt->bindParam(':bmdc', $bmdc);
      $insert_stmt->bindParam(':contact', $contact);
      $insert_stmt->bindParam(':email', $email);
      $insert_stmt->bindParam(':password', $password);

      if($insert_stmt->execute()){
        $insert_stmt = $db->prepare("SET @count = 0");
        $insert_stmt->execute();

        $insert_stmt = $db->prepare("UPDATE doctor SET doctor_id = @count:= @count + 1");
        $insert_stmt->execute();

        $insert_stmt = $db->prepare("ALTER TABLE doctor AUTO_INCREMENT = 1");
        $insert_stmt->execute();
          echo "<script>alert('doctor Added Successfully');</script>";
          $query = "SELECT * FROM doctor WHERE email = :email AND password = :password";
                $statement = $db->prepare($query);
                $statement->execute(
                     array(
                          ':email'     =>     $email,
                          ':password'     =>     $password
                     )
                );
                $count = $statement->rowCount();
                if($count > 0)
                {
                     $_SESSION["email"] = $email;
                     $_SESSION["bmdc"] = $bmdc;
                     header("location:doctor_degree.php");
                }
        }else{
          echo "<script>alert('doctor Not Added');</script>";
        }
    }else{
        echo "<script>alert('Something Wrong');</script>";
    }
    }else{
        echo "<script>alert('Invalid BMDC Number! Please Try Again...');</script>";
    }
    
    
      
    
  }

?>
    <!doctype html>
    <html class="fixed">

    <head>
        <!-- Basic -->
        <meta charset="UTF-8">
        <title>Doctor Registration</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="icon" href="assets/icon/Industry-Icon-10%20(48).ico">
        <!-- contact Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <!-- Web Fonts  -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
        <!-- Vendor CSS -->
        <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
        <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
        <link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
        <link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />
        <!-- Specific Page Vendor CSS -->
        <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
        <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
        <link rel="stylesheet" href="assets/vendor/morris/morris.css" />
        <!-- Theme CSS -->
        <link rel="stylesheet" href="assets/stylesheets/theme.css" />
        <!-- Skin CSS -->
        <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />
        <!-- Theme Custom CSS -->
        <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">
        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="../css/style.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="css/signin.css" rel="stylesheet">
        <!-- Head Libs -->
        <script src="assets/vendor/modernizr/modernizr.js"></script>
    </head>

    <body class="text-center">
        <div class="container">
            <center>
                <a href="../index.php" style="text-docoration:none;"><h1 class="head-link-responsive" >LOCATION BASED DOCTOR RECOMMENDATION<br>SYSTEM</h1></a>
                <br> </center>
            <form class="form-signin" action="" method="post" accept-charset="utf-8">
                <h1 class="h3 mb-3 font-weight-normal">Doctors Registration</h1>
                <input class="form-control" type="text" placeholder="Doctor Name" autocomplete="off" name="doctor_name" />
                <input class="form-control" type="text" placeholder="BMDC Number" autocomplete="off" name="bmdc" />
                <input class="form-control" type="text" placeholder="Contact Number" autocomplete="off" name="contact" />
                <input class="form-control" type="text" placeholder="Email" autocomplete="off" name="email" />
                <input class="form-control" type="password" placeholder="Password" autocomplete="off" name="password" />
                <input class="btn btn-lg btn-primary btn-block" type="submit" name="add_doctor" value="Next" />
                <br>
                <p>Login here <a href="index.php">Doctor Login</a></p>
                <br>
                <br>
                <p>Copyright©2019 Developed by <a href="#">Tamanna Tasnim</a></p>
            </form>
        </div>
        <!-- Vendor -->
        <script src="assets/vendor/jquery/jquery.js"></script>
        <script src="assets/vendor/jquery-browser-contact/jquery.browser.contact.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
        <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
        <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
        <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
        <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
        <!-- Specific Page Vendor -->
        <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
        <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
        <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
        <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
        <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
        <script src="assets/vendor/flot/jquery.flot.js"></script>
        <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
        <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
        <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
        <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
        <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
        <script src="assets/vendor/raphael/raphael.js"></script>
        <script src="assets/vendor/morris/morris.js"></script>
        <script src="assets/vendor/gauge/gauge.js"></script>
        <script src="assets/vendor/snap-svg/snap.svg.js"></script>
        <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
        <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
        <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
        <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>
        <!-- Theme Base, Components and Settings -->
        <script src="assets/javascripts/theme.js"></script>
        <!-- Theme Custom -->
        <script src="assets/javascripts/theme.custom.js"></script>
        <!-- Theme Initialization Files -->
        <script src="assets/javascripts/theme.init.js"></script>
        <!-- Examples -->
        <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>
    </body>

    </html>