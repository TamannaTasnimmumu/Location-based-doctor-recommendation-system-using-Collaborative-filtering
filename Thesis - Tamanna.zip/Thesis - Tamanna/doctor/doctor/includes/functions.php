<?php
	//session_start();
	include_once 'dbconnection.php';

	function fill_test_select_box($db){
		$output = '';
		$sql = "SELECT * FROM test";
		$res = $db->prepare($sql);
		$res->execute();
		$results = $res->fetchAll(PDO::FETCH_ASSOC);
		foreach ($results as $row) {
		$output .= '<option value="'.$row['test_name'].'">'.$row['test_name'].'</option>';
		}
		return $output;
	}

	function lastId(){
		global $db;
    $sql = "SELECT max(sr) as id from invoice_order";
    $stmt = $db->prepare($sql);
    $stmt->execute();
		$stmt->bindColumn('id', $lastId);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $lastId;
	}



 ?>
