<?php
  //include 'login_success.php';
session_start();
include 'includes/dbconnection.php';
if(isset($_REQUEST['add'])){
    $bmdc = $_SESSION['bmdc'];
    $degree = $_REQUEST['degree'];
    
    if(empty($degree)){
      $error = "Please enter degree";
    }
    
    if(!isset($error)){
      $sql = "INSERT INTO doctor_degree(bmdc, degree) VALUES (:bmdc, :doc_degree)";
      $insert_stmt = $db->prepare($sql);
      $insert_stmt->bindParam(':bmdc', $bmdc);
      $insert_stmt->bindParam(':doc_degree', $degree);
 
      if($insert_stmt->execute()){
        echo'<div class="alert alert-success fade in col-sm-4 animated slideInRight" >
        <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
        <strong>Success!</strong>Degree Added successfully.
        <script>
            setTimeout(function() {
                $(".alert").fadeOut(1000);
                $(".alert").remove(2000);
            }, 3000);
        </script>
    </div';
      }else{
          echo'<div class="alert alert-success fade in col-sm-4 animated slideInRight" >
        <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
        <strong>Success!</strong>Not Success! Please Try Again...
        <script>
            setTimeout(function() {
                $(".alert").fadeOut(1000);
                $(".alert").remove(2000);
            }, 3000);
        </script>
    </div';
      }

    }
    
}else if(isset($_REQUEST['next'])){
    header("location:doctor_specialty.php");
}

?>
    <!doctype html>
    <html class="fixed">

    <head>
        <!-- Basic -->
        <meta charset="UTF-8">
        <title>Doctor Registration</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="icon" href="assets/icon/Industry-Icon-10%20(48).ico">
        <!-- contact Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <!-- Web Fonts  -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
        <!-- Vendor CSS -->
        <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
        <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
        <link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
        <link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />
        <!-- Specific Page Vendor CSS -->
        <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
        <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
        <link rel="stylesheet" href="assets/vendor/morris/morris.css" />
        <!-- Theme CSS -->
        <link rel="stylesheet" href="assets/stylesheets/theme.css" />
        <!-- Skin CSS -->
        <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />
        <!-- Theme Custom CSS -->
        <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">
        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="../css/style.css" rel="stylesheet">
        <!-- Head Libs -->
        <script src="assets/vendor/modernizr/modernizr.js"></script>
    </head>

    <body class="text-center">
        <div class="container">
            <center>
                <a href="../index.php" style="text-docoration:none;"><h1 class="head-link-responsive" >LOCATION BASED DOCTOR RECOMMENDATION<br>SYSTEM</h1></a>
                <br> </center>
                <div class="container" style="margin-bottom:25%;">
                     <form method="post" action="doctor_degree.php">
                        <table style="width:50%; margin-left:25%;">
                           <caption class="text-center" style="margin-bottom:5%; margin-top:5%;"><h2>Select Educational Qualification</h2></caption>
                               <tr>
                                   <td style="width:50%;">
                                    <select name="degree" id="degree" class="form-control invoice-box-size-width">
                                        <option>Select Educational Qualification</option>
                                        <?php
                                        $sql = "SELECT * FROM degree";
                                        $res = $db->prepare($sql);
                                        $res->execute();
                                        $results = $res->fetchAll(PDO::FETCH_ASSOC);
                                        foreach ($results as $row) {
                                          echo '<option value="'.$row['degree'].'">'.$row['degree'].'</option>';
                                        }

                                        ?>
                                    </select>
                                </td>
                                <td style="width:5%;"> </td>
                                <td style="width:20%;"><button type="submit" name="add" class="btn-primary form-control">Add</button></td>
                                <td style="width:5%;"> </td>
                                <td style="width:20%;"><button type="submit" name="next" class="btn-primary form-control">Next</button></td>
                               </tr>

                          </table>
                        
                    </form>
                </div>
                <br>
                <br>
                <p>Copyright©2019 Developed by <a href="#">Tamanna Tasnim</a></p>

        </div>
        <!-- Vendor -->
        <script src="assets/vendor/jquery/jquery.js"></script>
        <script src="assets/vendor/jquery-browser-contact/jquery.browser.contact.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
        <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
        <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
        <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
        <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
        <!-- Specific Page Vendor -->
        <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
        <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
        <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
        <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
        <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
        <script src="assets/vendor/flot/jquery.flot.js"></script>
        <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
        <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
        <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
        <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
        <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
        <script src="assets/vendor/raphael/raphael.js"></script>
        <script src="assets/vendor/morris/morris.js"></script>
        <script src="assets/vendor/gauge/gauge.js"></script>
        <script src="assets/vendor/snap-svg/snap.svg.js"></script>
        <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
        <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
        <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
        <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
        <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>
        <!-- Theme Base, Components and Settings -->
        <script src="assets/javascripts/theme.js"></script>
        <!-- Theme Custom -->
        <script src="assets/javascripts/theme.custom.js"></script>
        <!-- Theme Initialization Files -->
        <script src="assets/javascripts/theme.init.js"></script>
        <!-- Examples -->
        <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>
    </body>

    </html>